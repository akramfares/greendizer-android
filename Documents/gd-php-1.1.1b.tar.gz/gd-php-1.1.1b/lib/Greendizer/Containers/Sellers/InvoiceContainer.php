<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @subpackage  Greendizer_Containers_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Containers_InvoiceContainerBase
 */
require_once 'Greendizer/Containers/InvoiceContainerBase.php';

/**
 * @see Greendizer_Collections_Sellers_InvoiceCollection
 */
require_once 'Greendizer/Collections/Sellers/InvoiceCollection.php';

/**
 * @see Greendizer_Resources_Sellers_Invoice
 */
require_once 'Greendizer/Resources/Sellers/Invoice.php';

/**
 * @see Greendizer_Resources_Sellers_InvoiceReport
 */
require_once 'Greendizer/Resources/Sellers/InvoiceReport.php';

/**
 * Represents an invoice container for sellers in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @subpackage  Greendizer_Containers_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Containers_Sellers_InvoiceContainer extends Greendizer_Containers_InvoiceContainerBase {

    /**
     * Returns the collection of invoices for a search query 
     *
     * @param string $queryString   Query of the search
     * @return Greendizer_Collections_Sellers_InvoiceCollection 
     */
    public function search($queryString) {
        parse_str($queryString, $query);
        return new Greendizer_Collections_Sellers_InvoiceCollection($this, new Greendizer_Net_Uri($this->getBaseUri()->getAbsoluteUri(), $queryString));
    }

    /**
     * Retrieves an invoice given its ID
     *
     * @param string $id    invoice ID
     * @return Greendizer_Resources_Sellers_Invoice 
     */
    public function getById($id) {
        $emailUri = new Greendizer_Net_Uri(substr($this->getBaseUri()->getAbsoluteUri(), 0, (-1) * strlen('invoices/')));
        $invoice = new Greendizer_Resources_Sellers_Invoice($this->getClient(), $emailUri, $id);
        $invoice->refresh();
        return $invoice;
    }

    /**
     * Returns a collection containing all the invoices available
     *
     * @return Greendizer_Collections_Sellers_InvoiceCollection 
     */
    public function getAll() {
        return new Greendizer_Collections_Sellers_InvoiceCollection($this, new Greendizer_Net_Uri($this->getBaseUri()->getAbsoluteUri()));
    }

    /**
     * Sends an invoice as an XMLi string to the server and returns an InvoiceReport object
     *
     * @param type $xmliString  XMli string representing the invoice
     * @return Greendizer_Resources_Sellers_InvoiceReport
     * @throws Greenidzer_Net_Exception 
     */
    public function send($xmliString) {

        $request = new Greendizer_Net_Request(
                        Greendizer_Net_HttpMethods::POST,
                        $this->getBaseUri(),
                        array('Accept' => 'application/json'),
                        $this->getClient()->getAuthType(),
                        $this->getClient()->getCredentials(),
                        $xmliString,
                        Greendizer_Net_ContentTypes::APPLICATION_XML
        );

        $response = $request->getResponse();

        if ($response->getStatusCode() == Greendizer_Net_HttpStatusCodes::HTTP_ACCEPTED) {
            $emailUri = new Greendizer_Net_Uri(substr($this->getBaseUri()->getAbsoluteUri(), 0, (-1) * strlen('invoices/')));
            $arr = explode('/', $response->getHeader('location'));
            $id = $arr[sizeof($arr)-2];
            $report = new Greendizer_Resources_Sellers_InvoiceReport(
                            $this->getClient(),
                            $emailUri,
                            $id
            );
            $report->__set('state', Greendizer_Resources_Sellers_InvoiceReportStatus::ACCEPTED);
            $report->sync(json_decode($response->getData()));
            return $report;
        }

        throw new Greendizer_Net_Exception('Could not send the invoice, server status code is: ' . $response->getStatusCode() .'\n'. $response->getData());
    }

}

?>
