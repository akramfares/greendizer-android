<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @subpackage  Greendizer_Containers_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Containers_EmailContainerBase
 */
require_once 'Greendizer/Containers/EmailContainerBase.php';

/**
 * @see Greendizer_Collections_Sellers_EmailCollection
 */
require_once 'Greendizer/Collections/Sellers/EmailCollection.php';

/**
 * @see Greendizer_Resources_Sellers_Email
 */
require_once 'Greendizer/Resources/Sellers/Email.php';

/**
 * Represents an email container for sellers in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @subpackage  Greendizer_Containers_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Containers_Sellers_EmailContainer extends Greendizer_Containers_EmailContainerBase {

    /**
     * Gets the collection corresponding to a query string
     *
     * @param string $queryString   Query string to search for
     * @return Greendizer_Collections_Sellers_EmailCollection 
     */
    public function search($queryString) {
        parse_str($queryString, $query);
        return new Greendizer_Collections_Sellers_EmailCollection($this, new Greendizer_Net_Uri($this->getBaseUri()->getAbsoluteUri(), $queryString));
    }

    /**
     * Gets an email given its ID
     *
     * @param string $id    ID of the email
     * @return Greendizer_Resources_Sellers_Email 
     */
    public function getById($id) {
        $resource = new Greendizer_Resources_Sellers_Email($this->getClient(), $id);
        $resource->refresh();
        return $resource;
    }

    /**
     * Returns a collection of all the Emails
     *
     * @return Greendizer_Collections_Sellers_EmailCollection 
     */
    public function getAll() {
        return new Greendizer_Collections_Sellers_EmailCollection($this, new Greendizer_Net_Uri($this->getBaseUri()->getAbsoluteUri()));
    }

}

?>
