<?php

/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @subpackage  Greendizer_Containers_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */
/**
 * @see Greendizer_Containers_ThreadContainerBase
 */
require_once 'Greendizer/Containers/ThreadContainerBase.php';

/**
 * @see Greendizer_Collections_Sellers_ThreadCollection
 */
require_once 'Greendizer/Collections/Sellers/ThreadCollection.php';

/**
 * @see Greendizer_Resources_Sellers_Thread
 */
require_once 'Greendizer/Resources/Sellers/Thread.php';

/**
 * Represents an thread container for sellers in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @subpackage  Greendizer_Containers_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Containers_Sellers_ThreadContainer extends Greendizer_Containers_ThreadContainerBase {

    /**
     * Returns the collection of threads for a search query 
     *
     * @param string $queryString   Query of the search
     * @return Greendizer_Collections_Sellers_ThreadCollection 
     */
    public function search($queryString) {
        parse_str($queryString, $query);
        return new Greendizer_Collections_Sellers_ThreadCollection($this, new Greendizer_Net_Uri($this->getBaseUri()->getAbsoluteUri(), $queryString));
    }

    /**
     * Retrieves a thread given its ID
     *
     * @param string $id    thread ID
     * @return Greendizer_Resources_Sellers_Thread 
     */
    public function getById($id) {
        $uri = new Greendizer_Net_Uri(substr($this->getBaseUri()->getAbsoluteUri(), 0, (-1) * strlen('threads/')));
        return new Greendizer_Resources_Sellers_Thread($this->getClient(), $uri, $id);
    }

    /**
     * Returns a collection containing all the threads available
     *
     * @return Greendizer_Collections_Sellers_ThreadCollection 
     */
    public function getAll() {
        return new Greendizer_Collections_Sellers_ThreadCollection($this, new Greendizer_Net_Uri($this->getBaseUri()->getAbsoluteUri()));
    }
    
    /**
     * Opens and returns and new thread
     *
     * @param string $recipient   Thread recipient
     * @param string $subject     Thread subject
     * @param string $message     Thread message content
     * @return Greendizer_Resources_Sellers_Thread
     */
    public function open($recipient, $subject, $message) {
        return parent::open($recipient, $subject, $message);
    }

    /**
     * Creates and returns a thread object
     *
     * @param array $resourceProperties Key/Value pairs of property names and values
     * @return Greendizer_Resources_Buyers_Thread
     */
    protected function create($resourceProperties) {
        //Send data on the server
        $response = parent::create($resourceProperties);

        //Build and return the desired object
        $userUri = new Greendizer_Net_Uri(substr($this->getBaseUri()->getAbsoluteUri(), 0, (-1) * strlen('threads/')));
        $resource = new Greendizer_Resources_Sellers_Thread(
                        $this->client,
                        $userUri,
                        Greendizer_Net_Etag::parseEtagString($response->getHeader('etag'))->getId()
        );
        $resource->sync(json_decode($response->getData()), Greendizer_Net_Etag::parseEtagString($response->getHeader('etag')));
        return $resource;
    }

}

?>
