<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_DAL_Container
 */
require_once 'Greendizer/DAL/Container.php';

/**
 * Represents an thread container in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Containers_ThreadContainerBase extends Greendizer_DAL_Container{

    /**
     * Opens and returns and new thread
     *
     * @param string $recipient   Thread recipient
     * @param string $subject     Thread subject
     * @param string $message     Thread message content
     * @return Greendizer_Resources_ThreadBase
     */
    public function open($recipient, $subject, $message) {
        $data = array(
            'recipient' => $recipient,
            'subject' => $subject,
            'message' => $message
        );

        return $this->create($data);
    }
}

?>
