<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_DAL_Container
 */
require_once 'Greendizer/DAL/Container.php';

/**
 * Represents an message container in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Containers_MessageContainerBase extends Greendizer_DAL_Container {
    
    /**
     * Sends a new message and returns its object
     *
     * @param string $text  Message text
     * @return Greendizer_Resources_MessageBase
     */
    public function send($text){
        $data = array ('text' => $text);
        return $this->create($data);
    }
}

?>
