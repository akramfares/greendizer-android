<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @subpackage  Greendizer_Containers_Buyers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */
/**
 * @see Greendizer_Containers_InvoiceContainerBase
 */
require_once 'Greendizer/Containers/InvoiceContainerBase.php';

/**
 * @see Greendizer_Collections_Buyers_InvoiceCollection
 */
require_once 'Greendizer/Collections/Buyers/InvoiceCollection.php';

/**
 * @see Greendizer_Resources_Buyers_Invoice
 */
require_once 'Greendizer/Resources/Buyers/Invoice.php';

/**
 * Represents an invoice container for buyers in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Containers
 * @subpackage  Greendizer_Containers_Buyers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Containers_Buyers_InvoiceContainer extends Greendizer_Containers_InvoiceContainerBase {

    /**
     * Returns the collection of invoices for a search query 
     *
     * @param string $queryString   Query of the search
     * @return Greendizer_Collections_Buyers_InvoiceCollection 
     */
    public function search($queryString) {
        return new Greendizer_Collections_Buyers_InvoiceCollection($this, new Greendizer_Net_Uri($this->getBaseUri()->getAbsoluteUri(), $queryString));
    }

    /**
     * Retrieves an invoice given its ID
     *
     * @param string $id    invoice ID
     * @return Greendizer_Resources_Buyers_Invoice 
     */
    public function getById($id) {
        $emailUri = new Greendizer_Net_Uri(substr($this->getBaseUri()->getAbsoluteUri(), 0, (-1) * strlen('invoices/')));
        $invoice = new Greendizer_Resources_Buyers_Invoice($this->getClient(), $emailUri, $id);
        $invoice->refresh();
        return $invoice;
    }

    /**
     * Returns a collection containing all the invoices available
     *
     * @return Greendizer_Collections_Buyers_InvoiceCollection 
     */
    public function getAll() {
        return new Greendizer_Collections_Buyers_InvoiceCollection($this, new Greendizer_Net_Uri($this->getBaseUri()->getAbsoluteUri()));
    }

}

?>
