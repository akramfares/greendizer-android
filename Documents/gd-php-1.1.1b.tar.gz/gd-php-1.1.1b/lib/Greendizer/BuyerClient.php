<?php
/**
 * Greendizer PHP Library
 *
 * @category    Greendizer
 * @package     Greendizer_Client
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Client
 */
require_once 'Greendizer/Client.php';

/**
 * @see Greendizer_Resources_Buyers_Buyer
 */
require_once 'Greendizer/Resources/Buyers/Buyer.php';

/**
 * Represents a Greendizer Buyer Client
 *
 * @category    Greendizer
 * @package     Greendizer_Client
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_BuyerClient extends Greendizer_Client{

    /**
     * Initializes a new instance of BuyerClient
     *
     * @param string $authType Authentication type
     * @param array $args Array including Authentication credentials
     */
    public function __construct($args) {
        parent::__construct($args);

    }

    /**
     * Returns Buyer Uri
     *
     * @return Greendizer_Net_Uri
     */
    public function getUri() {
        return new Greendizer_Net_Uri(self::API_BASE_URI.'buyers/');
    }

    /**
     * Returns client user
     *
     * @return Greendizer_Resources_Buyers_Buyer
     */
    public function getUser() {
        $this->user = new Greendizer_Resources_Buyers_Buyer($this);
        $this->user->refresh();
        return parent::getUser();
    }




}

?>
