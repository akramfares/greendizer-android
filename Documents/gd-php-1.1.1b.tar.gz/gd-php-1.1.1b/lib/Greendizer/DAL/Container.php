<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_DAL
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_DAL_Collection 
 */
require_once 'Greendizer/DAL/Collection.php';

/**
 * Represents a resource container
 * 
 * @category    Greendizer
 * @package     Greendizer_DAL
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
abstract class Greendizer_DAL_Container {

    /**
     * Client which initiated the container
     *
     * @var Greendizer_Client
     */
    protected $client;
    /**
     * Uri of the container
     *
     * @var Greendizer_Net_Uri
     */
    protected $baseUri;

    /**
     * Initializes a new instance of the container
     *
     * @param Greendizer_Client $client     Client initiating the container
     * @param Greendizer_Net_Uri $uri       Uri of the container
     */
    public function __construct(Greendizer_Client $client, Greendizer_Net_Uri $uri) {
        $this->client = $client;
        $this->baseUri = $uri;
    }

    /**
     * Returns the container's client
     * 
     * @return Greendizer_Client
     */
    public function getClient() {
        return $this->client;
    }

    /**
     * Returns the Base Uri of the container
     *
     * @return Greendizer_Net_Uri
     */
    public function getBaseUri() {
        return $this->baseUri;
    }
    
    /**
     * Returns the total number of resources on the server
     * 
     * @return integer
     */
    public function getTotal(){
        return $this->getAll()->getCount();
    }
    
    /**
     * Returns the collection of resources for a search query 
     *
     * @param string $queryString   Query of the search
     * @return Greendizer_DAL_Collection 
     */
    public function search($queryString) {
        
    }

    /**
     * Retrieves a resource given its ID
     *
     * @param string $id    Resource ID
     * @return Greendizer_DAL_Resource 
     */
    public function getById($id) {

    }

    /**
     * Returns a collection containing all the resources available
     *
     * @return Greendizer_DAL_Collection 
     */
    public function getAll() {
        
    }

    /**
     * Creates a resource and returns the server response
     *
     * @param array $resourceProperties Key/Value pairs of property names and values
     * @return Greendizer_Net_Response
     */
    protected function create($resourceProperties) {
        $request = new Greendizer_Net_Request(
                        Greendizer_Net_HttpMethods::POST,
                        $this->baseUri,
                        array('Accept' => 'application/json'),
                        $this->client->getAuthType(),
                        $this->client->getCredentials(),
                        http_build_query($resourceProperties)
        );
        $response = $request->getResponse();
        if ($response->getStatusCode() != Greendizer_Net_HttpStatusCodes::HTTP_CREATED) {
            throw new Exception('Error Code: ' . $response->getStatusCode() .'\n' . $response->getData());
        }
        return $response;
    }

}

?>
