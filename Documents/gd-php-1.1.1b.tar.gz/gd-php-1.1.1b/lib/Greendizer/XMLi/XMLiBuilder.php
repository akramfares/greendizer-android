<?php
/**
 * Greendizer PHP Library
 *
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

require_once 'Greendizer/XMLsec/xmlseclibs.php';

/**
 * Represents an XMLi Builder
 *
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_XMLiBuilder {

	/**
	 * Builder invoices array
	 *
	 * @var array
	 */
	private $invoices = array();

	/**
	 * Namespaces array
	 *
	 * @var array
	 */
	private $namespaces = array();

	/**
	 * Initalizes an XMLi builder object
	 */
	public function __construct() {

	}

	/**
	 * Gets the invoices array
	 *
	 * @return array
	 */
	public function getInvoices(){
		return $this->invoices;
	}

	/**
	 * Gets the Namespaces
	 *
	 * @return array
	 */
	public function getNamespaces(){
		$this->namespaces = array();
		foreach($this->invoices as $invoice){
			$namespaces = $invoice->getNamespaces();
			foreach($namespaces as $ns){
				array_push($this->namespaces, $ns);
			}
		}
		return $this->namespaces;
	}

	/**
	 * Adds invoice to the builder
	 *
	 * @param Greendizer_XMLi_Invoice $invoice
	 */
	public function addInvoice(Greendizer_XMLi_Invoice $invoice) {
		array_push($this->invoices, $invoice);
	}

	/**
	 * String representation of the XMLi invoice
	 *
	 * @return string
	 */
	public function toXMLi() {
		//Header
		$result = '<?xml version="1.0" encoding="UTF-8"?>';
		$this->getNamespaces();
		//Namespaces
		$result .= '<xmli version="gd-xmli-1.1">';
		$result .= '<invoices>';

		//Invoices
		foreach($this->invoices as $invoice){
			$result .= '<invoice>';
			$result .= $invoice;
			$result .= '</invoice>';
		}
		$result .= '</invoices>';
		$result .= '</xmli>';

		return $result;
	}

	/**
	 * String representation of the signed XMLi document
	 *
	 * @return string
	 */
	public function __toString() {

		$xmli = $this->toXMLi();

		$doc = new DOMDocument();
			
		$doc->loadXML($xmli);

		$objDSig = new XMLSecurityDSig();

		$objDSig->setCanonicalMethod(XMLSecurityDSig::EXC_C14N);

		$objDSig->addReference($doc, XMLSecurityDSig::SHA1, array('http://www.w3.org/2000/09/xmldsig#enveloped-signature'));

		$privobjKey = new XMLSecurityKey(XMLSecurityKey::RSA_SHA1, array('type'=>'private'));
			
		$privobjKey->loadKey(dirname(__FILE__) .'/../XMLsec/rsa.private', TRUE);

		$objDSig->sign($privobjKey);
		
		$publicobjKey = new XMLSecurityKey(XMLSecurityKey::RSA_SHA1, array('type'=>'public'));
		
		$publicobjKey->loadKey(dirname(__FILE__) .'/../XMLsec/rsa.public', TRUE);

		$objDSig->addRSAPublicKey($publicobjKey, TRUE, TRUE);

		$objDSig->appendSignature($doc->documentElement);
			
		return $doc->saveXML();
	}
}

?>
