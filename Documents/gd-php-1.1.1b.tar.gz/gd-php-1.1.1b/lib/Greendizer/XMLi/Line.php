<?php

/**
 * Greendizer PHP Library
 *
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_XMLi_ExtensibleElement
 */
require_once 'Greendizer/XMLi/ExtensibleElement.php';

/**
 * Represents a line in XMLi
 *
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_Line extends Greendizer_XMLi_ExtensibleElement {

    /**
     * Array of discounts in a line
     *
     * @var array
     */
    private $discounts = array();

    /**
     * Array of taxes in a line
     *
     * @var array
     */
    private $taxes = array();

    /**
     * date of a line
     *
     * @var int
     */
    private $date;

    /**
     * name of the line
     *
     * @var string
     */
    private $name;

    /**
     * description of the line
     *
     * @var string
     */
    private $description;

    /**
     * quantity of products
     *
     * @var float
     */
    private $quantity;

    /**
     * unit price of a product
     *
     * @var float
     */
    private $unitPrice;

    /**
     * group line
     *
     * @var Greendizer_XMLi_Group
     */
    private $group;

    /**
     * @var string
     */
    private $sscc;

    /**
     * @var string
     */
    private $gln;

    /**
     * @var string
     */
    private $gtin;

    /**
     * @var string
     */
    private $unit;

    /**
     * The Greendizer_XMLi_Line class constructor
     *
     * @return string
     */
    public function __construct() {

    }

    /**
     * Gets the discounts
     *
     * @return array
     */
    public function getDiscounts() {
        return $this->discounts;
    }

    /**
     * Gets the taxes
     *
     * @return array
     */
    public function getTaxes() {
        return $this->taxes;
    }

    /**
     * Add a tax
     *
     * @param Greendizer_XMLi_Tax $tax
     */
    public function addTax(Greendizer_XMLi_Tax $tax) {
        array_push($this->taxes, $tax);
    }

    /**
     * Add a discount
     *
     * @param Greendizer_XMLi_Discount $discount
     */
    public function addDiscount(Greendizer_XMLi_Discount $discount) {
        array_push($this->discounts, $discount);
    }

    /**
     * Get the date
     *
     * @return int
     */
    public function getDate() {
        return $this->date;
    }

    /**
     * Set a date
     *
     * @param int $date
     */
    public function setDate($date) {
        $this->date = $date;
    }

    /**
     * Get the line's name
     *
     * @return string
     */
    public function getName() {
        return $this->name;
    }

    /**
     * Set the line's name
     *
     * @param strings
     */
    public function setName($name) {
        $this->name = $name;
    }

    /**
     * Get the line's description
     *
     * @return string
     */
    public function getDescription() {
        return $this->description;
    }

    /**
     * Set the line's description
     *
     * @param string $description
     */
    public function setDescription($description) {
        $this->description = $description;
    }

    /**
     * Get quantity of products in a line
     *
     * @return float
     */
    public function getQuantity() {
        return $this->quantity;
    }

    /**
     * Set quantity of products in a line
     *
     * @param float $quantity
     */
    public function setQuantity($quantity) {
        $this->quantity = $quantity;
    }

    /**
     * Get the unit price
     *
     * @return float
     */
    public function getUnitPrice() {
        return $this->unitPrice;
    }

    /**
     * Set the unit price
     *
     * @return float
     */
    public function setUnitPrice($unitPrice) {
        $this->unitPrice = $unitPrice;
    }

    /**
     * Get the group
     *
     * @return Greendizer_XMLi_Group
     */
    public function getGroup() {
        return $this->group;
    }

    /**
     * Set a group
     *
     * @param Greendizer_XMLi_Group $group
     */
    public function setGroup($group) {
        $this->group = $group;
    }

    /**
     * Get the sscc
     *
     * @return string
     */
    public function getSscc() {
        return $this->sscc;
    }

    /**
     * Set the sscc
     *
     * @param string $sscc
     */
    public function setSscc($sscc) {
        $this->sscc = $sscc;
    }

    /**
     * Get the gln
     *
     * @return string
     */
    public function getGln() {
        return $this->gln;
    }

    /**
     * Set the gln
     *
     * @param string $gln
     */
    public function setGln($gln) {
        $this->gln = $gln;
    }

    /**
     * Get the gtin
     *
     * @return string
     */
    public function getGtin() {
        return $this->gtin;
    }

    /**
     * Set the gtin
     *
     * @param string $gtin
     */
    public function setGtin($gtin) {
        $this->gtin = $gtin;
    }

    /**
     * Get the unit
     *
     * @return string
     */
    public function getUnit() {
        return $this->unit;
    }

    /**
     * Set the unit
     *
     * @param string $unit
     */
    public function setUnit($unit) {
        $this->unit = $unit;
    }

    /**
     * Calculates the total of the invoice line
     *
     * @return type
     */
    public function total() {
        $gross = $this->unitPrice * $this->quantity;

        $discounts = 0;
        foreach ($this->discounts as $discount) {
            $discounts += $discount->compute($gross);
        }

        $taxes = 0;
        foreach ($this->taxes as $tax) {
            $taxes += $tax->compute($gross - $discounts);
        }

        return $gross - $discounts + $taxes;
    }

    /**
     * String representation of a line
     *
     * @return string
     */
    public function __toString() {

        $result = '<date>' . $this->date . '</date>';
        $result .= '<name>' . $this->name . '</name>';
        if (isset($this->description)) {
            $result .= '<description>' . $this->description . '</description>';
        }
        $result .= '<quantity>' . $this->quantity . '</quantity>';
        if (isset($this->unit)) {
            $result .= '<unit>' . $this->unit . '</unit>';
        }
        $result .= '<unitPrice>' . $this->unitPrice . '</unitPrice>';

        if (isset($this->gln)) {
            $result .= '<gln>' . $this->gln . '</gln>';
        }
        if (isset($this->sscc)) {
            $result .= '<sscc>' . $this->sscc . '</sscc>';
        }
        if (isset($this->gtin)) {
            $result .= '<gtin>' . $this->gtin . '</gtin>';
        }

        if (sizeof($this->taxes) > 0) {
            $result .= '<taxes>';
            foreach ($this->taxes as $tax) {
                $result .= $tax->__toString();
            }
            $result .= '</taxes>';
        }

        if (sizeof($this->discounts) > 0) {
            $result .= '<discounts>';
            foreach ($this->discounts as $discount) {
                $result .= $discount->__toString();
            }
            $result .= '</discounts>';
        }

        if (sizeof($this->elements) > 0) {
            $result .= '<custom>';
            $result .= parent::__toString();
            $result .= '</custom>';
        }

        return $result;
    }

}

?>
