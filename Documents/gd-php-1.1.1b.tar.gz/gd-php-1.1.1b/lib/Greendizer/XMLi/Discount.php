<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_XMLi_Treatment
 */
require_once 'Greendizer/XMLi/Treatment.php';

/**
 * Represents a discount
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_Discount extends Greendizer_XMLi_Treatment{
    
    /**
     * String representation of the discount
     *
     * @return string 
     */
    
    public function __toString() {
        parent::treatmentToString('discount');
    }
    
}

?>
