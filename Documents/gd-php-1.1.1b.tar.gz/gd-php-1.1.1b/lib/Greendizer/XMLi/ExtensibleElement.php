<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * Represents an Extensible Element
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_ExtensibleElement {
    /**
     * Array of reserved namespaces
     *
     * @var Array
     */
    private static $reservedNameSpaces = array("gd");
    
    /**
     * Array of elements
     *
     * @var Array
     */
    protected $elements = array();
    
    /**
     * Array of namespaces
     *
     * @var Array
     */
    protected $namespaces = array();

    public function __construct() {
        
    }
    
     /**
     * Check if the elements array contains the given namespace
     *
     * @param Greendizer_XMLi_XMLiNamespace $ns
     * @return boolean 
     */

    public function containsElementsOfNamespace(Greendizer_XMLi_XMLiNamespace $ns) {
        return array_key_exists($ns->getName(), $this->elements);
    }

     /**
     * Check if the elements array contains the given namespace
     *
     * @param Greendizer_XMLi_XMLiNamespace $ns
     * @param string $name
     * @return boolean 
     */
    
    public function containsElement(Greendizer_XMLi_XMLiNamespace $ns, $name) {
        return key_exists($ns, $this->elements) && array_key_exists($name, $this->elements[$ns]);
    }
    
     /**
     * Get custom element
     *
     * @param Greendizer_XMLi_XMLiNamespace $ns
     * @param string $name
     * @return Array 
     */
    
    public function getCustomElement(Greendizer_XMLi_XMLiNamespace $ns, $name) {
        return $this->elements[$ns->getName()][$name];
    }

     /**
     * set custom element
     *
     * @param Greendizer_XMLi_XMLiNamespace $ns
     * @param string $name
     * @param string $value
     * @return Array 
     */
    
    public function setCustomElement(Greendizer_XMLi_XMLiNamespace $ns, $name, $value) {

        if (in_array($ns->getName(), self::$reservedNameSpaces)) {
            throw new Exception("Invalid name space '" . $ns->getName() . "'");
        }

        if (!$this->containsElementsOfNamespace($ns)) {
            $this->elements[$ns->getName()] = array($name => $value);
            $this->namespaces[$ns->getName()] = $ns;
            //array_push($this->namespaces, $ns);
        }


        $this->elements[$ns->getName()][$name] = $value;
    }
    
    /**
     * Get all namespaces
     *
     * @return Array
     */
    
    public function getNamespaces() {
        return $this->namespaces;
    }
    
    /**
     * String representation of an element
     *
     * @return string 
     */
    
    public function __toString() {
        $result='';
        foreach ($this->elements as $ns => $element) {
            foreach ($element as $key => $value) {
                $result.= '<' . $ns . ':' . $key . '>' . $value . '</' . $ns . ':' . $key . '>';
            }
        }
        return $result;
    }

}

?>
