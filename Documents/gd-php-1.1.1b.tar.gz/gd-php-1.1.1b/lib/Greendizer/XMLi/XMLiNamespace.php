<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * Represents an XML Namespace
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_XMLiNamespace {

    /**
     * Name of the namespace
     *
     * @var string 
     */
    private $name;
    
    /**
     * Uri of the namespace
     *
     * @var string 
     */
    private $uriString;

    /**
     * Initializes a new instance of a namespace
     *
     * @param string $name          namespace name
     * @param string $uriString     namespace uri
     */
    public function __construct($name, $uriString) {
        $this->name = $name;
        $this->uriString = $uriString;
    }

    /**
     * Gets the namespace name
     *
     * @return string 
     */
    public function getName() {
        return $this->name;
    }

    /**
     * Sets the Namespace Name
     *
     * @param type $name 
     */
    public function setName($name) {
        $this->name = $name;
    }

    /**
     * Gets a namespace Uri
     *
     * @return string 
     */
    public function getUriString() {
        return $this->uriString;
    }

    /**
     * Sets the Namespace Name
     *
     * @param string $uriString 
     */
    public function setUriString($uriString) {
        $this->uriString = $uriString;
    }

    /**
     * String representation of the namespace
     *
     * @return type 
     */
    public function __toString() {
        return 'xmlns:' . $this->name . '="' . $this->uriString . '"';
    }

}

?>
