<?php

/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * Represents a treatment in XMLi
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_Treatment {

    private $name;
    private $description;
    private $rate;
    private $baseInterval;
    private $type;

    /**
     * Initializes a new instalce of treatment
     * 
     */
    public function __contruct() {
        
    }

    /**
     * Gets Treatment name
     *
     * @return string 
     */
    public function getName() {
        return $this->name;
    }

    /**
     * Sets Treatment name
     *
     * @return string 
     */
    public function setName($name) {
        $this->name = $name;
    }

    /**
     * Gets Treatment description
     *
     * @return string 
     */
    public function getDescription() {
        return $this->description;
    }

    /**
     * Sets Treatment description
     *
     * @param string $description 
     */
    public function setDescription($description) {
        $this->description = $description;
    }

    /**
     * Gets Treatment rate
     *
     * @return string 
     */
    public function getRate() {
        return $this->rate;
    }

    /**
     * Sets Treatment rate
     *
     * @var string $rate
     */
    public function setRate($rate) {
        $this->rate = $rate;
    }

    /**
     * Gets the base interval
     *
     * @return Greendizer_XMLi_Interval
     */
    public function getBaseInterval() {
        return $this->baseInterval;
    }

    /**
     * Sets the base interval
     *
     * @var Greendizer_XMLi_Interval 
     */
    public function setBaseInterval(Greendizer_XMLi_Interval $baseInterval) {
        $this->baseInterval = $baseInterval;
    }

    /**
     * Gets the treatment type
     *
     * @return Greendizer_XMLi_RateType
     */
    public function getType() {
        return $this->type;
    }

    /**
     * Sets the treatment type
     *
     * @param string $type 
     */
    public function setType($type) {
        $this->type = $type;
    }

    /**
     * Computes the amount
     *
     * @param float $gross
     * @return float 
     */
    public function compute($gross) {

        if($gross == 0){
            return 0;
        }

        $result = 0;
        if ($this->baseInterval == null) {
            $result += ( $this->type == Greendizer_XMLi_RateType::FIXED) ? $this->rate : $gross * $this->rate / 100;
        } else if ($gross >= $this->baseInterval->lower) {
            $result += ( $this->type == Greendizer_XMLi_RateType::FIXED) ? $this->rate : min(array($gross, $this->baseInterval->upper)) * $this->rate / 100;
        }
        return $result;
    }

    /**
     * String representation of the treatment
     *
     * @param string $name
     * @return string 
     */
    public function treatmentToString($name) {
        $result = '<' . $name;
        $result .= ' type="' . $this->type . '"';
        if ($this->name != null) {
            $result .= ' name="' . $this->name . '"';
        }
        if ($this->description != null) {
            $result .= ' description="' . $this->description . '"';
        }
        if ($this->baseInterval != null) {
            $result .= ' base="' . $this->baseInterval . '"';
        }
        $result.= '>' . $this->rate . '</' . $name . '>';
        return $result;
    }

}

?>
