<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_XMLi_Treatment
 */
require_once 'Greendizer/XMLi/Treatment.php';

/**
 * Represents a tax in XMLi
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_Tax extends Greendizer_XMLi_Treatment{
   
    /**
     * Compute the discounts
     *
     * @param float 
     * @return float $grossMinusdiscounts
     */
    
    /**
     * String representation of the tax
     *
     * @return string 
     */
    public function __toString() {
        return parent::treatmentToString('tax');
    }
}

?>
