<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * Represents an interval
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_Interval {

    
    /**
     * the maximal value of an interval
     * 
     * @var int
     */
    private $upper;
    
    /**
     * the minimal value of an interval
     * 
     * @var int
     */
    private $lower;

    /**
     * Greendizer_XMLi_Interval constructor
     * 
     * @param int $upper
     * @param int $lower
     */
    
    public function __construct($upper, $lower) {
        $this->upper = $upper;
        $this->lower = $lower;
    }
    
    /**
     * Get the upper value
     * 
     * @return int
     */
    public function getUpper() {
        return $this->upper;
    }

    /**
     * Set the upper value
     * 
     * @param int $upper
     */
    public function setUpper($upper) {
        $this->upper = $upper;
    }

    /**
     * Get the lower value
     * 
     * @return int
     */
    
    public function getLower() {
        return $this->lower;
    }

    /**
     * Set the lower value
     * 
     * @param int $lower
     */
    
    public function setLower($lower) {
        $this->lower = $lower;
    }
   
    /**
     * String representing the interval
     * 
     * @return string
     */
    
    public function __toString() {
        return '['.$this->lower.','.$this->upper.']';
    }



}

?>
