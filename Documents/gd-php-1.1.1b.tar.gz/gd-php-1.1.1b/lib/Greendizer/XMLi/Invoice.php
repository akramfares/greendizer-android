<?php

/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_XMLi_ExtensibleElement
 *
 */
require_once 'Greendizer/XMLi/ExtensibleElement.php';

/**
 * Represents an invoice status
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_InvoiceStatus {
    const PAID = 'Paid';
    const DUE = 'Due';
    const CANCELED = 'Cancelled';
}

/**
 * Represents an address
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_Address {
    /**
     * The street address
     * 
     * @var string
     */
    private $streetAddress;
    
    /**
    * The street State
    *
    * @var string
    */
    private $state;
    
    /**
     * Other field, for more informations or the address is too long
     * 
     * @var string
     */
    private $other;
    
    /**
     * The zipcode
     * 
     * @var int
     */
    private $zipcode;
    
    /**
     * The name of city
     * 
     * @var string
     */
    private $city;
    
    /**
     * Country name
     * 
     * @var string
     */
    private $country;
    
    /**
     * Greendizer_XMLi_Address class constructor
     * 
     */
    public function __construct() {
        
    }
    
    /**
     * Get the street address
     * 
     * @return string
     */
    public function getStreetAddress() {
        return $this->streetAddress;
    }

    /**
     * Set the street address
     * 
     * @param string $street 
     */
    public function setStreetAddress($street) {
        $this->streetAddress = $street;
    }
    
    /**
    * Get the state 
    *
    * @return string
    */
    public function getState() {
    	return $this->state;
    }
    
    /**
     * Set the state 
     *
     * @param string $state
     */
    public function setState($state) {
    	$this->state = $state;
    }

    /**
     * Get the other value
     * 
     * @return string
     */
    public function getOther() {
        return $this->other;
    }

    /**
     * Set the other value
     * 
     * @param string $other 
     */
    public function setOther($other) {
        $this->other = $other;
    }

    /**
     * Get the zipcode value
     * 
     * @return int
     */
    public function getZipCode() {
        return $this->zipcode;
    }

    /**
     * Set the zipcode value
     * 
     * @param int $zipcode 
     */
    public function setZipCode($zipcode) {
        $this->zipcode = $zipcode;
    }

    /**
     * Get the city name
     * 
     * @return string
     */
    public function getCity() {
        return $this->city;
    }

    /**
     * Set the city name
     * 
     * @param string $city
     */
    public function setCity($city) {
        $this->city = $city;
    }

    /**
     * Get the coutry name
     * 
     * @return string
     */
    public function getCountry() {
        return $this->country;
    }

    /**
     * Set the country name
     * 
     * @param string $country 
     */
    public function setCountry($country) {
        $this->country = $country;
    }

    /**
     * String representation of the address
     * 
     * @return string
     */
    public function __toString() {
        $result = '<address>';
        if (isset($this->streetAddress)) {
        	$result .= '<streetAddress>' . $this->streetAddress . '</streetAddress>';
        }
        if (isset($this->state)) {
        	$result .= '<state>' . $this->state . '</state>';
        }
        if (isset($this->other)) {
            $result .= '<other>' . $this->other . '</other>';
        }
        $result .= '<zipcode>' . $this->zipcode . '</zipcode>';
        $result .= '<city>' . $this->city . '</city>';
        $result .= '<country>' . $this->country . '</country>';
        $result .= '</address>';
        return $result;
    }
}

/**
 * Represents a recipient
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */

class Greendizer_XMLi_Recipient {

	/**
	 * name of the recipient
	 * @var string
	 */
    private $name;
    
    /**
     * email for the recipient
     * @var string
     */
    private $email;
    /**
     * address of the recipient
     * @var Greendizer_XMLi_Address
     */
    private $address;
    /**
     *
     * @var Greendizer_XMLi_Address
     */
    private $deliveryAddress;
    
    /**
    * The Greendizer_XMLi_Recipient class constructor
    *
    */
    public function __construct() {
    	$this->address = new Greendizer_XMLi_Address();
    }

    /**
     * Returns the email
     * 
     * @return string
     */
    public function getEmail() {
        return $this->email;
    }

    /**
     * Set the email
     * 
     * @param string $email
     */
    public function setEmail($email) {
        $this->email = $email;
    }

    /**
     * Returns the name
     * 
     * @return string
     */
    public function getName() {
        return $this->name;
    }

    /**
     * Set the name
     * 
     * @param string $name
     */
    public function setName($name) {
        $this->name = $name;
    }

    /**
     * Returns the of the recipient
     *
     * @return Greendizer_XMLi_Address
     */
    public function getAddress() {
        return $this->address;
    }

    /**
     * String representation of the recipient object
     * 
     * @return string
     */
    public function recipientToString($name) {
        $result = '<' . $name . '>';
        $result .= '<name>' . $this->name . '</name>';
        if (isset($this->email)) {
        	$result .= '<email>' . $this->email . '</email>';
        }
        $result .= $this->address->__toString();
        $result .= '</' . $name . '>';
        return $result;
    }

}

class Greendizer_XMLi_Shipping {

	/**
	 * recipient object
	 * @var Greendizer_XMLi_Recipient
	 */
	private $recipient;

	/**
	* The Greendizer_XMLi_Shipping class constructor
	*
	*/
	public function __construct() {
		$this->recipient = new Greendizer_XMLi_Recipient();
	}
	
	/**
	 * Gets the shipping recipient
	 *
	 * @return Greendizer_XMLi_Address
	 */
	public function getRecipient() {
		return $this->recipient;
	}

	/**
	 * String representation of the delivery address
	 *
	 * @return string
	 */
	public function __toString() {
		$result = '<shipping>';
		$result .= $this->recipient->recipientToString('recipient');
		$result .= '</shipping>';
		return $result;
	}

}



/**
 * Represents an invoice in XMLi
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_Invoice extends Greendizer_XMLi_ExtensibleElement {

    /**
     * Represents the buyer of the invoice
     * 
     * @var Greendizer_XMLi_Recipient
     */
    private $buyer;
    
    /**
    * Represents the shipping information of the invoice
    *
    * @var Greendizer_XMLi_Shipping
    */
    private $shipping;
    
    /**
     * Array of groups inside the invoice
     * 
     * @var Array
     */
    private $groups = array();
    /**
     *
     * @var Greendizer_XMLi_XMLiBuilder
     */
    private $builder;
    
    /**
     * name of the invoice
     * @var string
     */
    private $name;
    
    /**
     * description of the invoice
     * @var string
     */    
    private $description;
    
    /**
     * name of the invoice
     * @var string
     */
    private $customId;
    
    /**
     * currency used in the invoice
     * @var string
     */
    private $currency;
    
    /**
     * date of the invoice represented as posix time
     * @var int
     */
    private $date;
    
    /**
     * due date represented as posix time
     * @var int
     */
    private $dueDate;
    
    /**
     * status of the invoice.
     * @var string
     */
    private $status;

    /**
     * Terms in the invoice
     * 
     * @var string
     */
    private $terms;

    /**
     * The Greendizer_XMLi_Invoice class constructor
     *
     */
    public function __construct() {
        $this->buyer = new Greendizer_XMLi_Recipient();
    }

    /**
     * Get the invoice buyer
     * 
     * @return Greendizer_XMLi_Recipient
     */
    public function getBuyer() {
        return $this->buyer;
    }
    
    /**
    * Gets the shipping information of the invoice
    *
    * @return Greendizer_XMLi_Shipping
    */
    public function getShipping() {
    	return $this->shipping;
    }
    
    /**
    * Sets the shipping information of the invoice
    *
    * @return Greendizer_XMLi_Shipping
    */
    public function setShipping(Greendizer_XMLi_Shipping $shipping) {
    	$this->shipping = $shipping;
    }

    /**
     * Get the invoice groups
     *  
     * @return Greendizer_XMLi_Recipient
     */
    public function getGroups() {
        return $this->groups;
    }

    /**
     * Add a group to the invoice
     * 
     * @param Greendizer_XMLi_Group $group
     */
    public function addGroup($group) {
        array_push($this->groups, $group);
    }

    /**
     * Gets the name of the invoice
     * 
     * @return string
     */
    public function getName() {
        return $this->name;
    }

    /**
     * Sets a name for the invoice
     * 
     * @param string $name
     */
    public function setName($name) {
        $this->name = $name;
    }

    /**
     * Gets the description of the invoice
     * 
     * @return string
     */
    public function getDescription() {
        return $this->description;
    }

    /**
     * Sets a description for the invoice
     * 
     * @param string $description
     */
    public function setDescription($description) {
        $this->description = $description;
    }

    /**
     * Gets the custom id of the invoice
     * 
     * @return string
     */
    public function getCustomId() {
        return $this->customId;
    }

    /**
     * Sets a custom id for the invoice
     * 
     * @param string $customId
     */
    public function setCustomId($customId) {
        $this->customId = $customId;
    }

    /**
     * Gets the currency of the invoice
     * 
     * @return string
     */
    public function getCurrency() {
        return $this->currency;
    }

    /**
     * Sets a currency to the invoice
     * 
     * @return string
     */
    public function setCurrency($currency) {
        $this->currency = $currency;
    }

    /**
     * Gets the date of the invoice as a string (yyyy-mm-dd)
     * 
     * @return int
     */
    public function getDate() {
        return $this->date;
    }

    /**
     * Sets a date for the invoice as a string (yyyy-mm-dd)
     * 
     * @param int $date
     */
    public function setDate($date) {
        $this->date = $date;
    }

    /**
     * Gets the due date of the invoice as a string (yyyy-mm-dd)
     * 
     * @return string
     */
    public function getDueDate() {
        return $this->dueDate;
    }

    /**
     * Sets the due date of the invoice as a string (yyyy-mm-dd)
     * 
     * @param int $dueDate
     */
    public function setDueDate($dueDate) {
        $this->dueDate = $dueDate;
    }

    /**
     * Gets the status of the invoice
     * 
     * @return string
     */
    public function getStatus() {
        return $this->status;
    }

    /**
     * Sets the status of the invoice
     * 
     * @param string $status
     */
    public function setStatus($status) {
        $this->status = $status;
    }

    /**
     * Gets the terms of the invoice
     * 
     * @return string
     */
    public function getTerms() {
        return $this->terms;
    }

    /**
     * Sets the terms of the invoice
     * 
     * @param string $terms
     */
    public function setTerms($terms) {
        $this->terms = $terms;
    }

    /**
     * Gets the invoice namespaces
     * 
     * @return array
     */
    public function getNamespaces() {
        foreach ($this->groups as $group) {
            $namespaces = $group->getNamespaces();
            foreach ($namespaces as $name=>$ns) {
                if (!key_exists($name, $this->namespaces)) {
                    $this->namespaces[$name]=$ns;
                }
            }
        }
        return $this->namespaces;
    }

    /**
     * Gets the XMLi Builder
     * 
     * @return Greendizer_XMLi_XMLiBuilder
     */
    public function getBuilder() {
        return $this->builder;
    }

    /**
     * Gets the total of the invoice
     * 
     * @return float
     */
    public function total() {
        $result = 0;
        foreach ($this->groups as $group) {
            $result += $group->total();
        }
        return $result;
    }

    /**
     * String representation of the invoice.
     * 
     * @return string
     */
    public function __toString() {
        $result = $this->buyer->recipientToString('buyer');
        if (isset($this->shipping)) {
        	$result .= $this->shipping->__toString();
        }
        $result .= '<name>' . $this->name . '</name>';
        if (isset($this->description)) {
            $result .= '<description>' . $this->description . '</description>';
        }
        $result .= '<date>' . $this->date . '</date>';
        $result .= '<dueDate>' . $this->dueDate . '</dueDate>';
        $result .= '<currency>' . $this->currency . '</currency>';
        $result .= '<status>' . strtolower($this->status) . '</status>';
        $result .= '<total>' . $this->total() . '</total>';

        if (isset($this->terms)) {
            $result .= '<terms>' . $this->terms . '</terms>';
        }
        if (isset($this->customId)) {
            $result .= '<customId>' . $this->customId . '</customId>';
        }



        $this->getNamespaces();
        //Namespaces
        $result .= '<body';
        foreach ($this->namespaces as $ns) {
            $result .= ' ' . $ns;
        }
        $result .= '>';

        //<groups>
        if (sizeof($this->groups > 0)) {
            $result .= '<groups>';
            foreach ($this->groups as $group) {
                $result .= '<group>';
                $result.= $group->__toString();
                $result .= '</group>';
            }
            $result .= '</groups>';
        }

        //<custom>
        if (sizeof($this->elements) > 0) {
            $result .= '<custom>';
            $result .= parent::__toString();
            $result .= '</custom>';
        }

        $result .= '</body>';
        return $result;
    }

}

?>
