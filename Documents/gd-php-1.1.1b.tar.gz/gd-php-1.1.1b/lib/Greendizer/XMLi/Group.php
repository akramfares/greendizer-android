<?php

/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer/XMLi/ExtensibleElement.php
 */
require_once 'Greendizer/XMLi/ExtensibleElement.php';

/**
 * Represents a group in XMLi
 * 
 * @category    Greendizer
 * @package     Greendizer_XMLi
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_XMLi_Group extends Greendizer_XMLi_ExtensibleElement {

     /**
     *
     * @var Greendizer_XMLi_Invoice
     */
    private $invoice;
    
     /**
     * represents an array of lines in a group
     *
     * @var Array
     */  
    private $lines = array();
    
     /**
     * name of the group
     * 
     * @var string
     */
    
    private $name;
    
     /**
     * description of a group
     * 
     * @var string
     */
    
    private $description;

    public function __construct() {
        
    }

     /**
     * Returns an invoice from the group
     *
     * @return Greendizer_XMLi_Invoice
     */

    
    public function getInvoice() {
        return $this->invoice;
    }

     /**
     * Set invoice to the group
     * 
     * @param Greendizer_XMLi_Invoice $invoice
     * @return Greendizer_XMLi_Invoice
     */
    
    public function setInvoice($invoice) {
        $this->invoice = $invoice;
    }

    /**
     * Get the group name
     * 
     * @return string
     */

    public function getName() {
        return $this->name;
    }
    
    /**
     * Set the group name
     * 
     * @param string $name
     * @return void
     */
    
    public function setName($name) {
        $this->name = $name;
    }

    /**
     * Get the group description
     * 
     * @return string
     */
    
    public function getDescription() {
        return $this->description;
    }

    /**
     * Set the group description
     * 
     * @param string $description
     */
    
    public function setDescription($description) {
        $this->description = $description;
    }

    /**
     * Get the group lines
     * 
     * @return Array
     */
 
    public function getLines() {
        return $this->lines;
    }

    /**
     * Set the group name
     * 
     * @param Array $lines
     */
    
    public function setLines($lines) {
        $this->lines = $lines;
    }

    /**
     * Add line to the group
     * 
     * @param  Greendizer_XMLi_Line $lines
     */
    
    public function addLine(Greendizer_XMLi_Line $line) {
        array_push($this->lines, $line);
    }

    
    /**
     * Get all namespaces
     * 
     * @return Array
     */
    
    public function getNamespaces() {
        foreach ($this->lines as $line) {
            $namespaces = $line->getNamespaces();
            foreach ($namespaces as $name=>$ns) {
                if (!key_exists($name, $this->namespaces)) {
                    $this->namespaces[$name]=$ns;
                }
            }
        }
        return $this->namespaces;
    }

    /**
     * Get the total
     * 
     * @return int
     */
    
    public function total() {
        $result = 0;
        foreach ($this->lines as $line) {
            $result += $line->total();
        }
        return $result;
    }

    /**
     * String representing the group
     * 
     * @return string
     */
    
    public function __toString() {
        $result = '';
        if (isset($this->name)) {
            $result = '<name>' . $this->name . '</name>';
        }
        if (isset($this->description)) {
            $result .= '<description>' . $this->description . '</description>';
        }

        $this->getNamespaces();
        //lines
        if (sizeof($this->lines) > 0) {
            $result .= '<lines>';
            foreach ($this->lines as $line) {
                $result .= '<line>';
                $result.= $line->__toString();
                $result .= '</line>';
            }
            $result .= '</lines>';
        }

        //custom
        if (sizeof($this->elements) > 0) {
            $result .= '<custom>';
            $result .= parent::__toString();
            $result .= '</custom>';
        }

        return $result;
    }

}

?>
