<?php
date_default_timezone_set("UTC");
/**
 * Greendizer PHP Library
 *
 * @category    Greendizer
 * @package     Greendizer_Client
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */
/**
 * @see Greendizer_Resources_User
 */
require_once 'Greendizer/Resources/User.php';

/**
 * @see Greendizer_Net_AuthenticationTypes
 */
require_once 'Greendizer/Net/AuthenticationTypes.php';

/**
 * Represents a Greendizer Client
 *
 * @category    Greendizer
 * @package     Greendizer_Client
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Client {

    const API_BASE_URI = 'https://api.greendizer.com/';

    /**
     * Client email address
     *
     * @var string
     */
    private $email;
    /**
     * Client password
     *
     * @var string
     */
    private $password;
    /**
     * OAuth Client Type
     *
     * @var string
     */
    private $OAuthClientType;
    /**
     * Authentification type
     *
     * @var string
     */
    private $authType;
    /**
     * Boolean for OAuth use
     *
     * @var boolean
     */
    private $usingOAuth;
    /**
     * OAuth token
     *
     * @var string
     */
    private $OAuthToken;
    /**
     * Client user
     *
     * @var Greendizer_User
     */
    protected $user;

    /**
     * Initializes a new instance of the Client class
     *
     * @param string $authType type of Authentication
     * @param array $args    Array of args depending on
     */
    public function __construct(array $args) {
        //case of Basic Auth
        if (sizeof($args) == 2) {
            if (!key_exists('email', $args) || !key_exists('password', $args)) {
                throw new InvalidArgumentException('Invalid Argument 2: Expected \'email\' and \'password\' keys in input array');
            }
            $this->email = $args['email'];
            $this->password = $args['password'];
            $this->usingOAuth = false;
            $this->authType = Greendizer_Net_AuthenticationTypes::BASIC;
            //case of OAuth
        } else if (sizeof($args) == 1) {
            if (!key_exists('token', $args)) {
                throw new InvalidArgumentException('Invalid Argument 2: Expected \'type\', \'token\' keys in input array');
            }
            $this->OAuthToken = $args['token'];
            $this->usingOAuth = true;
            $this->authType = Greendizer_Net_AuthenticationTypes::OAUTH;
        } else {
            //in case the first arg is not valid.
            Throw new InvalidArgumentException('Invalid Argument 1: Invalid Authentication Type');
        }
    }


    /**
     * Gets the client user
     *
     * @return Greendizer_Resources_User
     */
    public function getUser() {
        return $this->user;
    }

    /**
     * Gets tge client User
     *
     * @return Greendizer_Resources_User
     */
    public function User() {
        return $this->getUser();
    }

    /**
     * Gets the client email
     *
     * @return string
     */
    public function getEmail() {
        return $this->email;
    }

    /**
     * Gets the client password
     *
     * @return string
     */
    public function getPassword() {
        return $this->password;
    }

    /**
     * Gets Authentication type
     *
     * @return string
     */
    public function getAuthType() {
        return $this->authType;
    }

    /**
     * Returns OAuth Token
     *
     * @return string
     */
    public function getOAuthToken() {
        return $this->OAuthToken;
    }

    /**
     * Returns credentials Array
     *
     * If the Authentication type is OAuth, the array contains keys 'clientType' and token.
     * While for Basic Authentication, the array contains keys 'email' and password
     *
     * @return Array
     */
    public function getCredentials() {
        if ($this->usingOAuth) {
            $credentials = array('token' => $this->getOAuthToken());
        } else {
            $credentials = array('email' => $this->getEmail(), 'password' => $this->getPassword());
        }
        return $credentials;
    }

    /**
     * Returns boolean true if the client is using OAuth and false otherwise
     *
     * @return boolean
     */
    public function isUsingOAuth() {
        return $this->usingOAuth;
    }

}


?>
