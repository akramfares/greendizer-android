<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Collections
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_DAL_Collection
 */
require_once 'Greendizer/DAL/Collection.php';

/**
 * Represents a collection of Threads in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Collections
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Collections_ThreadCollectionBase extends Greendizer_DAL_Collection{

}

?>
