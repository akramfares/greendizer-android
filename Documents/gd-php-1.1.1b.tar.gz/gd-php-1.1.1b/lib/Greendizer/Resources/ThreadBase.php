<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_DAL_Resource
 */
require_once 'Greendizer/DAL/Resource.php';

/**
 * Represents a thread in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 * @abstract
 */
abstract class Greendizer_Resources_ThreadBase extends Greendizer_DAL_Resource{
    
    /**
     * Message container of the thread
     *
     * @var Greendizer_Container_MessageContainerBase
     */
    protected $messageContainer;
    
    /**
     * Gets the thread subject
     *
     * @return string 
     */
    public function getSubject(){
        return $this->__get('subject');
    }
    
    /**
     * Gets the thread snippet
     *
     * @return string 
     */
    public function getSnippet(){
        return $this->__get('snippet');
    }
    
    /**
     * Gets the thread last message
     *
     * @return type 
     */
    public function getLastMessage(){
        return $this->__get('lastMessage');
    }
    
    /**
     * Returns true if thread is flagged and false otherwise
     *
     * @return boolean 
     */
    public function isFlagged() {
        return ($this->__get('flagged') == 'true') ? true : false;
    }

    /**
     * Sets the thread flagged attribute
     *
     * @param boolean $flagged 
     */
    public function setFlagged($flagged) {
        ($flagged == true || $flagged == 1) ? $this->__set('flagged', 'true') : $this->__set('flagged', 'false');
    }
    
    /**
     * Returns true if read is flagged and false otherwise
     *
     * @return boolean 
     */
    public function isRead() {
        return ($this->__get('read') == 'true') ? true : false;
    }

    /**
     * Sets the thread read attribute
     *
     * @param boolean $read 
     */
    public function setRead($read) {
        ($read == true || $read == 1) ? $this->__set('read', 'true') : $this->__set('read', 'false');
    }
    
    /**
     * Gets the thread location
     *
     * @return string 
     */
    public function getLocation() {
        return $this->__get('location');
    }

    /**
     * Sets the thread location
     *
     * @param string $location 
     */
    public function setLocation($location) {
        $this->__set('location', $location);
    }
    

    
}

?>
