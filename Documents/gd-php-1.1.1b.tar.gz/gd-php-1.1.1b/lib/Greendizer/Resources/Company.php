<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Client
 */
require_once 'Greendizer/Client.php';

/**
 * @see Greendizer_DAL_Resource
 */
require_once 'Greendizer/DAL/Resource.php';

/**
 * @see Greendizer_Net_Uri
 */
require_once 'Greendizer/Net/Uri.php';

/**
 * Represents a Company in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Company extends Greendizer_DAL_Resource {

    /**
     * Returns the company Uri
     *
     * @return Greendizer_Net_Uri 
     */
    public function getUri() {
        return new Greendizer_Net_Uri('companies/' . $this->getId());
    }

    /**
     * Returns the company name
     *
     * @return string
     */
    public function getName() {
        return $this->__get('name');
    }

    /**
     * Returns the company description
     *
     * @return string 
     */
    public function getDescription() {
        return $this->__get('description');
    }

    /**
     * Return the company small logo uri
     *
     * @return string 
     */
    public function getSmallLogo() {
        return $this->__get('smallLogo');
    }

    /**
     * Returns the company large logo uri
     *
     * @return type 
     */
    public function getLargeLogo() {
        return $this->__get('largeLogo');
    }

}

/**
 * Represents an Employer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Employer extends Greendizer_Resources_Company {

    /**
     * Initializes a new instance of Employer
     *
     * @param Greendizer_Client $client 
     */
    public function __construct(Greendizer_Client $client) {
        parent::__construct($client);
    }

    /**
     * Returns the employer uri
     *
     * @return Greendizer_Net_Uri 
     */
    public function getUri() {
        return new Greendizer_Net_Uri($this->getClient()->getUser()->getUri()->getAbsoluteUri() . 'company/');
    }

}

?>
