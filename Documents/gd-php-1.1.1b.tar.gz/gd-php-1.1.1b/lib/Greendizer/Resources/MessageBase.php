<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_DAL_Resource
 */
require_once 'Greendizer/DAL/Resource.php';

/**
 * Represents an message in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
abstract class Greendizer_Resources_MessageBase extends Greendizer_DAL_Resource {

    /**
     * Uri of the thread to which the message belongs
     *
     * @var Greendizer_Net_Uri
     */
    public $threadUri;

    /**
     * Initializes a new instance of a message
     *
     * @param Greendizer_Client $client
     * @param Greendizer_Net_Uri $threadUri Thread the message belongs to
     * @param string $id        ID of the resource
     */
    public function __construct(Greendizer_Client $client,Greendizer_Net_Uri $threadUri, $id = null) {
        $this->threadUri = $threadUri;
        parent::__construct($client, $id);
    }

    /**
     * Gets the message Uri
     *
     * @return Greendizer_Net_Uri 
     */
    public function getUri() {
        return new Greendizer_Net_Uri($this->threadUri . 'messages/' . $this->getId());
    }

    /**
     * Gets the message text
     *
     * @return string 
     */
    public function getText() {
        return $this->__get('text');
    }

}

?>
