<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Resources_MessageBase
 */
require_once 'Greendizer/Resources/MessageBase.php';

/**
 * Represents a seller message in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Sellers_Message extends Greendizer_Resources_MessageBase{
    
}

?>
