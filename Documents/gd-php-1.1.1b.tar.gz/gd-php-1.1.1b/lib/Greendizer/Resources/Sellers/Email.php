<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Resources_EmailBase
 */
require_once 'Greendizer/Resources/EmailBase.php';

/**
 * @see Greendizer_Containers_Sellers_InvoiceContainer
 */
require_once 'Greendizer/Containers/Sellers/InvoiceContainer.php';

/**
 * Represents a seller email in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Sellers_Email extends Greendizer_Resources_EmailBase{
    
    /**
     * Returns the invoice container of the resource
     *
     * @return Greendizer_Containers_Sellers_InvoiceContainer
     */
    public function invoices(){
        $this->invoiceContainer = new Greendizer_Containers_Sellers_InvoiceContainer($this->getClient(), new Greendizer_Net_Uri($this->getUri()->getAbsoluteUri() . 'invoices/'));
        return $this->invoiceContainer;
    }
}

?>
