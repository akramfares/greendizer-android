<?php
/**
 * Greendizer PHP Library
 *
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Resources_InvoiceBase
 */
require_once 'Greendizer/Resources/InvoiceBase.php';

/**
 * Represents a seller invoice in Greendizer
 *
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Sellers_Invoice extends Greendizer_Resources_InvoiceBase{

    public function cancel() {
        $this->__set('canceled', 'true');
        $this->save();
    }
}

?>
