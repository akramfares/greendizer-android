<?php

/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */
/**
 * @see Greendizer_Resources_ThreadBase
 */
require_once 'Greendizer/Resources/ThreadBase.php';

/**
 * @see Greendizer_Containers_Sellers_MessageContainer
 */
require_once 'Greendizer/Containers/Sellers/MessageContainer.php';

/**
 * Represents a seller thread in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Sellers_Thread extends Greendizer_Resources_ThreadBase {

    /**
     * Thread user
     *
     * @var Greendizer_Net_Uri
     */
    private $userUri;

    /**
     * Initializes a new instance of a seller thread
     *
     * @param Greendizer_Client $client 
     * @param Greendizer_Net_Uri $uri       Thread User Uri
     * @param string $id 
     */
    public function __construct(Greendizer_Client $client, Greendizer_Net_Uri $uri, $id = null) {
        parent::__construct($client, $id);
        $this->userUri = $uri;
    }

    /**
     * Returns the Uri of the seller thread
     *
     * @return Greendizer_Net_Uri 
     */
    public function getUri() {
        return new Greendizer_Net_Uri($this->userUri->getAbsoluteUri() . 'threads/' . $this->getId());
    }

    /**
     * Returns the message container of the thread
     *
     * @return Greendizer_Containers_Sellers_ThreadContainer 
     */
    public function messages() {
        $this->messageContainer = new Greendizer_Containers_Sellers_MessageContainer($this->getClient(), new Greendizer_Net_Uri($this->getUri()->getAbsoluteUri() . 'messages/'));
        return $this->messageContainer;
    }

}

?>
