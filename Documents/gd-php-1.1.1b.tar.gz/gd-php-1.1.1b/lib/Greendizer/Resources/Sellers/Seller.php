<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Resources_User
 */
require_once 'Greendizer/Resources/User.php';

/**
 * @see Greendizer/Containers/Sellers/EmailContainer
 */
require_once 'Greendizer/Containers/Sellers/EmailContainer.php';

/**
 * @see Greendizer/Containers/Sellers/ThreadContainer
 */
require_once 'Greendizer/Containers/Sellers/ThreadContainer.php';

/**
 * Represents a seller in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Sellers_Seller extends Greendizer_Resources_User {

    /**
     * Seller Thread container
     *
     * @var Greendizer_Containers_Seller_ThreadContainer 
     */
    private $threadContainer;

    /**
     * Returns the Seller's email container
     *
     * @return Greendizer_Containers_Sellers_EmailContainer
     */
    public function emails() {
        $this->emailContainer = new Greendizer_Containers_Sellers_EmailContainer($this->getClient(), new Greendizer_Net_Uri($this->getUri()->getAbsoluteUri() . 'emails/'));
        return $this->emailContainer;
    }

    /**
     * Returns the Seller's thread container
     *
     * @return Greendizer_Containers_Sellers_ThreadContainer
     */
    public function threads() {
        $this->threadContainer = new Greendizer_Containers_Sellers_ThreadContainer($this->getClient(), new Greendizer_Net_Uri($this->getUri()->getAbsoluteUri() . 'threads/'));
        return $this->threadContainer;
    }

}

?>
