<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_DAL_Resource
 */
require_once 'Greendizer/DAL/Resource.php';

/**
 * Represents a seller invoice report in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Sellers_InvoiceReport extends Greendizer_DAL_Resource{
    
    /**
     * Uri of the Invoice report
     *
     * @var Greendizer_Net_Uri
     */
    private $emailUri;
    
    /**
     * Initializes a new instance of invoice report
     *
     * @param Greendizer_Client $client     
     * @param Greendizer_Net_Uri $emailUri  Uri of the email the report belongs to
     * @param type $id  Id of the report
     */
    public function __construct(Greendizer_Client $client,Greendizer_Net_Uri $emailUri, $id = null) {
        parent::__construct($client, $id);
        $this->emailUri = $emailUri;
    }
    
    /**
     * Gets the Uri of the invoice report
     *
     * @return Greendizer_Net_Uri 
     */
    public function getUri(){
        return new Greendizer_Net_Uri($this->emailUri.'invoices/reports/'.$this->getId());
    }
    
    /**
     * Gets the invoice report status
     *
     * @return string 
     */
    public function getStatus(){
        return $this->__get('state');
    }
    
    /**
     * Gets the invoice report count
     *
     * @return integer 
     */
    public function getCount(){
        return $this->__get('count');
    }
    
    /**
     * Gets the invoice report time
     *
     * @return integer 
     */
    public function getTime(){
        return $this->__get('time');
    }
    
    /**
     * Gets the invoice report size
     *
     * @return integer 
     */
    public function getSize(){
        return $this->__get('dataSize');
    }
    
    /**
     * Gets the invoice report hash
     *
     * @return string 
     */
    public function getSha1(){
        return $this->__get('sha1');
    }
}

/**
 * Enumerates the types of Invoice report statuses
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Sellers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Sellers_InvoiceReportStatus{
    /**
     * Value for status accepted
     */
    const ACCEPTED = 0;
    
    /**
     * Value for status running
     */
    const RUNNING=1;
    
    /**
     * Value for status postponed
     */
    const POSTPONED=2;
    
    /**
     * Value for status canceled
     */
    const CANCELED=3;
    
    /**
     * Value for status suceeded
     */
    const SUCEEDED=4;
    
    /**
     * Value for status failed
     */
    const FAILED=5;
    
}

?>
