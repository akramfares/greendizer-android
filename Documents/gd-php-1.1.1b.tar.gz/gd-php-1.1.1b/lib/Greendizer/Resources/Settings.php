<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Client
 */
require_once 'Greendizer/Client.php';

/**
 * @see Greendizer_Net_Uri
 */
require_once 'Greendizer/Net/Uri.php';

/**
 * @see Greendizer_DAL_Resource
 */
require_once 'Greendizer/DAL/Resource.php';

/**
 * Represents user settings in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Settings extends Greendizer_DAL_Resource {

    /**
     * Initializes a new instance of Settings
     *
     * @param Greendizer_Client $client 
     */
    public function __construct(Greendizer_Client $client) {
        parent::__construct($client);
    }

    /**
     * Returns the Uri of the user settings
     *
     * @return Greendizer_Net_Uri 
     */
    public function getUri() {
        return new Greendizer_Net_Uri($this->getClient()->getUser()->getUri()->getAbsoluteUri() . 'settings/');
    }
    
    /**
     * Returns the language setting
     *
     * @return string 
     */
    public function getLanguage(){
        return $this->__get('language');
    }
    
    /**
     * Returns the region setting
     *
     * @return string 
     */
    public function getRegion(){
        return $this->__get('region');
    }

    
}

?>
