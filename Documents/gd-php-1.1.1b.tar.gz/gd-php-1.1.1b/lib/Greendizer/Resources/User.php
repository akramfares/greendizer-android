<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Client
 */
require_once 'Greendizer/Client.php';

/**
 * @see Greendizer_Net_Uri
 */
require_once 'Greendizer/Net/Uri.php';

/**
 * @see Greendizer_DAL_Resource
 */
require_once 'Greendizer/DAL/Resource.php';

/**
 * @see Greendizer_DAL_Container
 */
require_once 'Greendizer/DAL/Container.php';

/**
 * @see Greendizer_Resources_Company
 */
require_once 'Greendizer/Resources/Company.php';

/**
 * @see Greendizer_Resources_Settings
 */
require_once 'Greendizer/Resources/Settings.php';

/**
 * Represents a Greendizer User in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_User extends Greendizer_DAL_Resource {

    /**
     * User settings
     *
     * @var Greendizer_Resources_Settings
     */
    private $settings;
    
    /**
     * User employer
     *
     * @var Greendizer_Resources_Employer 
     */
    protected $employer;
    
    /**
     * Email Container for the resource
     *
     * @var Greendizer_Containers_EmailContainerBase
     */
    protected $emailContainer;

    /**
     * Initializes a new instance of the user
     *
     * @param Greendizer_Client $client     The client initiating the user
     */
    public function __construct(Greendizer_Client $client) {
        parent::__construct($client);
        $this->settings = new Greendizer_Resources_Settings($client);
        $this->employer = new Greendizer_Resources_Employer($client);
    }

    /**
     * Returns the current User Uri
     *
     * @return Greendizer_Net_Uri 
     */
    public function getUri() {
        return new Greendizer_Net_Uri($this->getClient()->getUri()->getAbsoluteUri() . 'me/');
    }

    /**
     * Returns the user first name
     *
     * @return string 
     */
    public function getFirstName() {
        return $this->__get('firstname');
    }

    /**
     * Returns the user last name
     *
     * @return string 
     */
    public function getLastName() {
        return $this->__get('lastname');
    }

    /**
     * Returns the user full name
     *
     * @return string 
     */
    public function getFullName() {
        return $this->__get('firstname') . ' ' . $this->__get('lastname');
    }

    /**
     * Returns the user birthday 
     * 
     * The date is formatted as "m/d/Y g:i:s A"
     *
     * @return string 
     */
    public function getBirthday() {
        return gmdate("m/d/Y g:i:s A", $this->__get('birthday')/1000);
    }

    /**
     * Returns the user gender
     *
     * @return string 
     */
    public function getGender() {
        return $this->__get('gender');
    }

    /**
     * Returns the user avatar uri
     *
     * @return string 
     */
    public function getAvatar() {
        return $this->__get('avatar');
    }

    /**
     * Returns the user company
     *
     * @return Greendizer_Resources_Employer
     */
    public function getCompany(){ 
        $this->employer->refresh();
        return $this->employer;
    }

    /**
     * Returns the user settings
     *
     * @return Greendizer_Resources_Settings
     */
    public function getSettings() {
        $this->settings->refresh();
        return $this->settings;
    }


}

?>
