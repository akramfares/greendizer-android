<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Buyers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Resources_EmailBase
 */
require_once 'Greendizer/Resources/EmailBase.php';

/**
 * @see Greendizer_Containers_Buyers/InvoiceContainer
 */
require_once 'Greendizer/Containers/Buyers/InvoiceContainer.php';

/**
 * @see Greendizer_Containers_Buyers/ThreadContainer
 */
require_once 'Greendizer/Containers/Buyers/ThreadContainer.php';

/**
 * @see Greendizer_Net_Uri
 */
require_once 'Greendizer/Net/Uri.php';

/**
 * Represents a buyer email in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Buyers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Buyers_Email extends Greendizer_Resources_EmailBase {

    /**
     * Thread container of the email
     *
     * @var Greendizer_Containers_Buyers_ThreadContainer
     */
    private $threadContainer;

    /**
     * Returns the email thread container
     *
     * @return Greendizer_Containers_Buyers_ThreadContainer
     */
    public function threads() {
        $this->threadContainer = new Greendizer_Containers_Buyers_ThreadContainer($this->getClient(), new Greendizer_Net_Uri($this->getUri()->getAbsoluteUri() . 'threads/'));
        return $this->threadContainer;
    }
    
    /**
     * Return the email invoice container
     *
     * @return Greendizer_Containers_Buyers_InvoiceContainer
     */
    public function invoices() {
        $this->invoiceContainer = new Greendizer_Containers_Buyers_InvoiceContainer($this->getClient(), new Greendizer_Net_Uri($this->getUri()->getAbsoluteUri() . 'invoices/'));
        return $this->invoiceContainer;
    }

}

?>
