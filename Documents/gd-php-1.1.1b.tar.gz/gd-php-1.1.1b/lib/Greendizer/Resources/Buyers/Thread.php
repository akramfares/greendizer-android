<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Buyers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Resources_ThreadBase
 */
require_once 'Greendizer/Resources/ThreadBase.php';

/**
 * @see Greendizer_Containers_Buyers_MessageContainer
 */
require_once 'Greendizer/Containers/Buyers/MessageContainer.php';

/**
 * Represents a buyer thread in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Buyers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Buyers_Thread extends Greendizer_Resources_ThreadBase {

    /**
     * Thread seller
     *
     * @var Greendizer_Resources_Company 
     */
    private $seller;
    /**
     * Uri of the email which the thread belongs to
     *
     * @var Greendizer_Net_Uri 
     */
    private $emailUri;

    /**
     * Initializes a new instance of a buyer thread
     *
     * @param Greendizer_Client $client     Client used
     * @param Greendizer_Net_Uri $uri       Uri of the email to which the thread belongs
     * @param type $id                      ID of the Thread
     */
    public function __construct(Greendizer_Client $client, Greendizer_Net_Uri $uri, $id = null) {
        parent::__construct($client, $id);
        $this->emailUri = $uri;
    }

    /**
     * Gets the thread Uri
     *
     * @return Greendizer_Net_Uri 
     */
    public function getUri() {
        return new Greendizer_Net_Uri($this->emailUri->getAbsoluteUri() . 'threads/' . $this->getId());
    }

    /**
     * Gets the seller of the thread
     *
     * @return Greendizer_Resources_Company
     */
    public function getSeller() {
        //TODO: Need to implement the way to extract the Id from the seller URI !!
        $this->seller = new Greendizer_Resources_Company($client, $this->__get('sellerURI'));
        return $this->seller;
    }

    /**
     * Gets the message container of the thread
     *
     * @return Greendizer_Containers_Buyers_MessageContainer
     */
    public function messages() {
        $this->messageContainer = new Greendizer_Containers_Buyers_MessageContainer($this->getClient(), new Greendizer_Net_Uri($this->getUri()->getAbsoluteUri() . 'messages/'));
        return $this->messageContainer;
    }

}

?>
