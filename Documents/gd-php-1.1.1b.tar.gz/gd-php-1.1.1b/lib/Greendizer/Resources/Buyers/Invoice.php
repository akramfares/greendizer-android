<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Buyers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Resources_InvoiceBase
 */
require_once 'Greendizer/Resources/InvoiceBase.php';

/**
 * @see Greendizer_Resources_Company
 */
require_once 'Greendizer/Resources/Company.php';

/**
 * Represents a buyer invoice in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Buyers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Buyers_Invoice extends Greendizer_Resources_InvoiceBase{
    
    /**
     * Invoice seller
     *
     * @var Greendizer_Resources_Company 
     */
    private $seller;
    
    /**
     * Gets the invoice seller
     *
     * @return Greendizer_Resources_Company 
     */
    public function getSeller(){
        $this->seller = new Greendizer_Resources_Company($this->client, $this->__get('sellerURI'));
        return $this->seller;
    }


    public function getBuyerUri(){
        $buyerArray = $this->__get('buyer');
        return $buyerArray["uri"];
    }
}

?>
