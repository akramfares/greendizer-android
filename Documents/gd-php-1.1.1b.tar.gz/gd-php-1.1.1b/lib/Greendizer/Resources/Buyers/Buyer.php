<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Buyers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Resources_User
 */
require_once 'Greendizer/Resources/User.php';

/**
 * @see Greendizer/Containers/Buyers/EmailContainer
 */
require_once 'Greendizer/Containers/Buyers/EmailContainer.php';

/**
 * Represents a buyer in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @subpackage  Greendizer_Resources_Buyers
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Resources_Buyers_Buyer extends Greendizer_Resources_User {

    /**
     * Returns the Buyer emails container
     *
     * @return Greendizer_Containers_Buyers_EmailContainer
     */
    public function emails() {
        $this->emailContainer = new Greendizer_Containers_Buyers_EmailContainer($this->getClient(), new Greendizer_Net_Uri($this->getUri()->getAbsoluteUri() . 'emails/'));
        return $this->emailContainer;
    }

}

?>
