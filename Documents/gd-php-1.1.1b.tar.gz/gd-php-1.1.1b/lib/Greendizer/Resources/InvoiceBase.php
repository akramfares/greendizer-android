<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_DAL_Resource
 */
require_once 'Greendizer/DAL/Resource.php';

/**
 * Represents an invoice in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
abstract class Greendizer_Resources_InvoiceBase extends Greendizer_DAL_Resource {

    /**
     * Uri of the email that includes the invoice
     *
     * @var Greendizer_Net_Uri
     */
    private $emailUri;

    /**
     * Initializes a new instance of the invoice object
     *
     * @param Greendizer_Client $client
     * @param Greendizer_Net_Uri $emailUri     Uri of the email including the invoice
     * @param type $id 
     */
    public function __construct(Greendizer_Client $client, Greendizer_Net_Uri $emailUri, $id = null) {
        $this->emailUri = $emailUri;
        parent::__construct($client, $id);
    }

    /**
     * Gets the invoice Uri
     *
     * @return Greendizer_Net_Uri 
     */
    public function getUri() {
        return new Greendizer_Net_Uri($this->emailUri->getAbsoluteUri() . 'invoices/' . $this->getId());
    }

    /**
     * Gets the invoice name
     *
     * @return string 
     */
    public function getName() {
        return $this->__get('name');
    }

    /**
     * Gets the invoice description
     *
     * @return string 
     */
    public function getDescription() {
        return $this->__get('description');
    }

    /**
     * Gets the invoice currency
     *
     * @return string 
     */
    public function getCurrency() {
        return $this->__get('currency');
    }

    /**
     * Gets the invoice date
     *
     * @return string 
     */
    public function getDate() {
        return $this->__get('date');
    }

    /**
     * Gets the invoice due date
     *
     * @return string 
     */
    public function getDueDate() {
        return $this->__get('dueDate');
    }

    /**
     * Gets the invoice total
     *
     * @return float 
     */
    public function getTotal() {
        return (float) $this->__get('total');
    }
    
    /**
    * Gets the invoice secret key
    *
    * @return float
    */
    public function getSecretKey() {
    	return $this->__get('secretKey');
    }
    

    /**
     * Gets the invoice body
     *
     * @return string 
     */
    public function getBody() {
        return $this->__get('body');
    }

    /**
     * Gets the invoice location
     *
     * @return string 
     */
    public function getLocation() {
        return $this->__get('location');
    }

    /**
     * Sets the invoice location
     *
     * @param string $location 
     */
    public function setLocation($location) {
        $this->__set('location', $location);
    }

    /**
     * Returns true if invoice is canceled and false otherwise
     *
     * @return boolean 
     */
    public function isCanceled() {
        return ($this->__get('canceled') == 'true') ? true : false;
    }

    /**
     * Return true if invoice is payable and false otherwise
     *
     * @return boolean 
     */
    public function isPayable() {
        return ($this->__get('payable') == 'true') ? true : false;
    }

    /**
     * Returns true if invoice is flagged and false otherwise
     *
     * @return boolean 
     */
    public function isFlagged() {
        return ($this->__get('flagged') == 'true') ? true : false;
    }

    /**
     * Sets the invoice flagged attribute
     *
     * @param boolean $flagged 
     */
    public function setFlagged($flagged) {
        ($flagged == true || $flagged == 1) ? $this->__set('flagged', 'true') : $this->__set('flagged', 'false');
    }

    /**
     * Returns true if invoice is read and false otherwise
     *
     * @return boolean 
     */
    public function isRead() {
        return ($this->__get('read') == 'true') ? true : false;
    }

    /**
     * Sets the invoice read attribute
     *
     * @param boolean $read 
     */
    public function setRead($read) {
        ($read == true || $read == 1) ? $this->__set('read', 'true') : $this->__set('read', 'false');
    }

    /**
     * Returns true if invoice is paid and false otherwise
     *
     * @return boolean 
     */
    public function isPaid() {
        return ($this->__get('paid') == 'true') ? true : false;
    }

    /**
     * Sets the invoice paid attribute
     *
     * @param boolean $paid 
     */
    public function setPaid($paid) {
        ($paid == true || $paid == 1) ? $this->__set('paid', 'true') : $this->__set('paid', 'false');
    }

    /**
     * Gets the invoice buyer name
     * 
     * @return string
     */
    public function getBuyerName(){
        $buyer = $this->__get('buyer');
        return $buyer->name;
    }
    
    public function getBuyerEmail(){
    	$buyer = $this->__get('buyer');
        return $buyer->email;
    }

    public function getBuyerAddress(){
        $buyer = $this->__get('buyer');
        return $buyer->address;
    }

    public function getShipping(){
        return $this->__get('shipping');
    }
    
    public function getRecipientName(){
    	$shipping = $this->__get('shipping');
    	if($shipping != null){
    		return $shipping->recipient->name;
    	}
    	return null;
    }
    
    public function getRecipientEmail(){
    	$shipping = $this->__get('shipping');
    	if($shipping!= null && isset($shipping->recipient->email)){
    		return $shipping->recipient->email;
    	}
    	return null;
    }
    
    public function getRecipientAddress(){
    	$shipping = $this->__get('shipping');
    	if($shipping != null){
    		return $shipping->recipient->address;
    	}
    	return null;
    }
}

?>
