<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_DAL_Resource
 */
require_once 'Greendizer/DAL/Resource.php';

/**
 * Represents an email address in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Resources
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
abstract class Greendizer_Resources_EmailBase extends Greendizer_DAL_Resource {

    /**
     * Invoice container
     *
     * @var Greendizer_Resources_InvoiceContainerBase 
     */
    protected $invoiceContainer;

    
    /**
     * Returns the email uri
     *
     * @return Greendizer_Net_Uri 
     */
    public function getUri() {
        return new Greendizer_Net_Uri($this->getClient()->User()->getUri()->getBaseUri() . 'emails/' . $this->getId());
    }

    /**
     * Gets the email label
     *
     * @return string 
     */
    public function getLabel() {
        return $this->__get('label');
    }

    /**
     * Sets the email label
     *
     * @param string $label 
     */
    public function setLabel($label) {
        $this->__set('label', $label);
    }

}

?>
