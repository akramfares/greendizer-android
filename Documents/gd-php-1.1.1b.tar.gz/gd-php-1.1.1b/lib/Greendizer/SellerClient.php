<?php

/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Client
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */
/**
 * @see Greendizer_Client
 */
require_once 'Greendizer/Client.php';

/**
 * @see Greendizer_Resources_Sellers_Seller
 */
require_once 'Greendizer/Resources/Sellers/Seller.php';

/**
 * Represents a Greendizer Seller Client
 * 
 * @category    Greendizer
 * @package     Greendizer_Client
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_SellerClient extends Greendizer_Client {

    /**
     * Initializes a new instance of SellerClient
     *
     * @param string $authType Authentication type
     * @param array $args Array including Authentication credentials
     */
    public function __construct($args) {
        parent::__construct($args);
    }

    /**
     * Returns Seller Uri
     *
     * @return Greendizer_Net_Uri
     */
    public function getUri() {
        return new Greendizer_Net_Uri(self::API_BASE_URI . 'sellers/');
    }

    /**
     * Returns client user
     * 
     * @return Greendizer_Resources_Sellers_Seller
     */
    public function getUser() {
        $this->user = new Greendizer_Resources_Sellers_Seller($this);
        $this->user->refresh();
        return parent::getUser();
    }



}

?>
