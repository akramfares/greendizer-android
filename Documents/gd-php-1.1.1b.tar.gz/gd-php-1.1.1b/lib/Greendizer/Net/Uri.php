<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * Represents a Uri in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Net_Uri {

    /**
     * Base Uri string
     *
     * @var string 
     */
    private $baseUri;
    
    /**
     * Array of query parameters
     *
     * @var array 
     */
    private $queryParameters;
    
    /**
     * Full sting Uri
     *
     * @var string 
     */
    private $absoluteUri;

    /**
     * Initializes a new intance of a Uri
     *
     * @param string $baseUri           Base Uri string
     * @param array $queryParameters    Parameters of the query string
     */
    public function __construct($baseUri, $queryParameters="") {
        //$this->validate($baseUri, $page, $queryParameters);
        $this->baseUri = $baseUri;
        $this->queryParameters = $queryParameters;
        $this->constructURI();
    }

    /**
     * Gets the base Uri
     * 
     * @return string 
     */
    public function getBaseUri() {
        return $this->baseUri;
    }

    /**
     * Returns the query parameters string
     *
     * @return string
     */
    public function getQueryParameters() {
        return $this->queryParameters;
    }

    /**
     * Gets the full absolute Uri string
     *
     * @return string 
     */
    public function getAbsoluteUri() {
        return $this->absoluteUri;
    }
    
    /**
     * Contructs the string Uri from Base Uri and Parameters
     * 
     */
    private function constructURI() {
        $uri = $this->baseUri;
        //take off the slash to add an eventual query
        if ($uri[strlen($uri) - 1] == '/') {
            $uri = substr($uri, 0, strlen($uri) - 1);
        }
        if(strlen($this->queryParameters)==0){
            $this->absoluteUri = $uri.'/';
        }else{
            $this->absoluteUri = $uri . '/?q='. $this->queryParameters .'/';
        }
    }

}

?>
