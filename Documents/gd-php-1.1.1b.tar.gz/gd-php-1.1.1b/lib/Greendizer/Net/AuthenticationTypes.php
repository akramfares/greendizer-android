<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * Enumeration of the Authentication types
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Net_AuthenticationTypes {
    
    const BASIC = 'Basic';
    const OAUTH = 'OAuth';
    
    /**
     * Array of Authetication Types
     *
     * @var array 
     */
    public static $TYPES = array('Basic', 'OAuth');
}

?>
