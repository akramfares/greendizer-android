<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * @see Greendizer_Net_Request
 */
require_once 'Greendizer/Net/Request.php';

/**
 * Represents an Http Response
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */

class Greendizer_Net_Response {

    /**
     * Request that initiated the response
     *
     * @var Greendizer_Net_Request
     */
    private $request;
    
    /**
     * Response header array
     *
     * @var array 
     */
    private $headers;
    
    /**
     * Response body
     *
     * @var string
     */
    private $data;

    /**
     * Initializes an new instance of the response
     *
     * @param Greendizer_Net_Request $request Request initiating the response
     * @param array $headers                  Response Header Array   
     * @param string $data                      Response body Array
     */
    public function  __construct($request, $headers, $data) {
        $this->request = $request;
        $this->headers = $headers;
        $this->data = $data;
    }

    /**
     * Gets the request initiating the response
     *
     * @return Greendizer_Net_Request 
     */
    public function getRequest(){
        return $this->request;
    }
    
    /**
     * Gets the response body
     *
     * @return string 
     */
    public function getData(){
        return $this->data;
    }

    /**
     * Gets the reponse headers
     *
     * @return array 
     */
    public function getHeaders(){
        return $this->headers;
    }

    /**
     * Gets a specific header value in the response
     *
     * @param string $key   Header Name
     * @return string       Header Value
     */
    public function getHeader($key){
        if(array_key_exists($key, $this->headers)){
            return $this->headers[$key];
        }
       throw new Exception('Header does not exist in response');
    }
    
    /**
     * Gets the Status Code of the request
     *
     * @return string   Http status code 
     */
    public function getStatusCode(){
        return $this->getHeader('http_code');

    }
    
    
}
?>
