<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * Represents an Etag in Greendizer
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Net_Etag {

    /**
     * ID of the Etag
     *
     * @var string Id of the Etag 
     */
    private $id;
    
    /**
     * Millisecond Unix Timestamp of last modification
     *
     * @var integer 
     */
    private $lastModified;
    
    /**
     * Etag string representation
     *
     * @var string Etag String 
     */
    private $etagString;

    /**
     * Initializes an new Etag
     *
     * @param string $id
     * @param integer $lastModified     Last modified millisecond Unix timestamp
     */
    public function __construct($id, $lastModified){
        $this->id = $id;
        $this->lastModified = date(DATE_COOKIE, $lastModified/1000);
        $this->etagString = $lastModified.'-'.$id;
    }

    /**
     * Return the ID of the Etag
     *
     * @return string 
     */
    public function getId(){
        return $this->id;
    }

    /**
     * Returns the last modification millisecond Unix timestamp
     *
     * @return type 
     */
    public function getLastModified(){
        return $this->lastModified;
    }

    /**
     * Returns the Etag String representation
     *
     * @return string 
     */
    public function getEtagString(){
        return $this->etagString;
    }

    /**
     *
     * @param type $etagString
     * @return Greendizer_Net_Etag 
     */
    public static function parseEtagString($etagString){
        $etagarray = explode('-',$etagString);
        return new Greendizer_Net_Etag($etagarray[1], $etagarray[0]);
    }
}
?>
