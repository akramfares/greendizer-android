<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * Enumeration of the HTTP Methods
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Net_HttpMethods {
   
    const GET = 'GET';
    const POST = 'POST';
    const PATCH = 'PATCH';
    const PUT = 'PUT';
    const DELETE = 'DELETE';
    const HEAD = 'HEAD';
    const OPTIONS = 'OPTIONS';
    
    /**
     * Array of HTTP Methods
     *
     * @var array
     */
    public static $METHODS = array('GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'HEAD', 'OPTIONS');
    
}
?>
