<?php
/**
 * Greendizer PHP Library
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/Licence.txt
 * @version     1.0
 */

/**
 * Enumeration of the content-types
 * 
 * @category    Greendizer
 * @package     Greendizer_Net
 * @copyright   Copyright (c) 2009-2010, Greendizer S.A - All rights reserved.
 * @license     Greendizer/License.txt
 */
class Greendizer_Net_ContentTypes {
    
    const APPLICATION_XML = 'application/xml';
    const TEXT_HTML = 'text/html';
    const APPLICATION_JSON = 'application/json';
    const ENCODED_URL = 'application/x-www-form-urlencoded';
    const TEXT_PLAIN = 'text/plain';
    
    /**
     * Array of content types
     *
     * @var array
     */
    public static $TYPES = array('application/xml','text/html','application/json','application/x-www-form-urlencoded','text/plain');
    
}

?>
